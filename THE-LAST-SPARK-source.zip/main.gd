extends Node2D
## THE LAST SPARK  (hackathon theme: BOUNCE BACK)
## Godot 4.7.2. The world is drawn in code and the Ninja Frog uses its supplied animation sheets.
## Controls: A/D or LEFT/RIGHT walk, double-tap W to toggle run, SPACE/UP jump and double-jump, ESC pause, R restart.

const GROUND_Y := 520.0
const WALK_SPEED := 225.0
const RUN_SPEED := 360.0
const WALK_ACCEL := 1100.0
const RUN_ACCEL := 1450.0
const MOVE_BRAKE := 1800.0
const LEVEL_LEN := 48000.0
const CHECKPOINT_GAP := 4000.0
const PARKOUR_SCENE := preload("res://parkour_course.tscn")
const AMBIENCE_STREAM := preload("res://JDSherbert - Ambiences Music Pack - Swamp of Digeridoos.mp3")

# ---------- LIGHT DOME TUNING ----------
const START_R := 400.0
const MIN_R := 220.0
const MAX_R := 560.0
const HIT_SHRINK := 26.0
const CLEAR_GROW := 42.0
const STREAK_GROW := 8.0
const BOUNCE_R := 390.0
const VICTORY_SPREAD_R := 3400.0
const RUN_DOUBLE_TAP_WINDOW := 0.38

# Full-screen darkness with soft holes for: the player's dome, the goal orb, the nearest lamp.
const DARK_SHADER := """
shader_type canvas_item;
uniform vec2 rect_size = vec2(1152.0, 648.0);
uniform vec2 c1 = vec2(300.0, 400.0);
uniform float r1 = 260.0;
uniform vec2 c2 = vec2(-9999.0);
uniform float r2 = 0.0;
uniform vec2 c3 = vec2(-9999.0);
uniform float r3 = 0.0;
uniform float dark = 0.985;

float hole(vec2 p, vec2 c, float r) {
	if (r <= 0.0) {
		return 0.0;
	}
	float d = distance(p, c);
	return 1.0 - smoothstep(r * 0.55, r, d);
}

void fragment() {
	vec2 p = UV * rect_size;
	float l = hole(p, c1, r1);
	l = max(l, hole(p, c2, r2));
	l = max(l, hole(p, c3, r3));
	COLOR = vec4(0.0, 0.0, 0.03, dark * (1.0 - l));
}
"""


# =====================================================================
#  PLAYER  (origin = feet)
# =====================================================================
class Player extends Node2D:
	const IDLE_TEX := preload("res://assets/player/idle.png")
	const RUN_TEX := preload("res://assets/player/run.png")
	const JUMP_TEX := preload("res://assets/player/jump.png")
	const FALL_TEX := preload("res://assets/player/fall.png")
	const HIT_TEX := preload("res://assets/player/hit.png")
	const DOUBLE_JUMP_TEX := preload("res://assets/player/double_jump.png")
	const WALL_JUMP_TEX := preload("res://assets/player/wall_jump.png")
	const ANIM_FRAMES := {"idle": 11, "run": 12, "jump": 1, "fall": 1, "hit": 7, "double": 6, "wall": 5}
	var vy := 0.0
	var vx := 0.0
	var on_ground := true
	var ground_y := 520.0
	var t := 0.0
	var squash := 0.0
	var hurt := 0.0
	var coyote_timer := 0.0
	var jumps_used := 0
	var facing := 1.0
	var anim_name := "idle"
	var anim_frame := 0
	var anim_timer := 0.0
	var double_jump_timer := 0.0
	var was_on_ground := true

	func _init() -> void:
		texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

	func hitbox() -> Rect2:
		return Rect2(position.x - 14.0, position.y - 42.0, 28.0, 42.0)

	func can_jump() -> bool:
		return on_ground or coyote_timer > 0.0 or jumps_used < 2

	func jump() -> void:
		var is_double := not on_ground and coyote_timer <= 0.0 and jumps_used >= 1
		vy = -650.0 if is_double else -690.0
		on_ground = false
		coyote_timer = 0.0
		jumps_used = 2 if is_double else 1
		if is_double:
			double_jump_timer = 0.34
		squash = -0.16

	func step(delta: float, direction: float, platforms: Array[Rect2], sprinting: bool = false) -> void:
		was_on_ground = on_ground
		var top_speed := RUN_SPEED if sprinting else WALK_SPEED
		var acceleration := RUN_ACCEL if sprinting else WALK_ACCEL
		var desired := direction * top_speed
		vx = move_toward(vx, desired, (acceleration if direction != 0.0 else MOVE_BRAKE) * delta)
		if absf(vx) < 2.0 and direction == 0.0:
			vx = 0.0
		if direction != 0.0:
			facing = signf(direction)
		t += delta * (0.4 + absf(vx) / RUN_SPEED)
		var previous_y := position.y
		position.x += vx * delta
		if on_ground and position.y < ground_y - 0.5:
			var supported := false
			for platform in platforms:
				if absf(position.y - platform.position.y) < 1.0 and position.x + 12.0 > platform.position.x and position.x - 12.0 < platform.end.x:
					supported = true
					break
			if not supported:
				on_ground = false
				coyote_timer = 0.12
		if not on_ground:
			coyote_timer = maxf(0.0, coyote_timer - delta)
			vy += 1550.0 * delta
			position.y += vy * delta
			if vy >= 0.0:
				var landing_y := ground_y
				for platform in platforms:
					var overlaps_x := position.x + 13.0 > platform.position.x and position.x - 13.0 < platform.end.x
					if overlaps_x and previous_y <= platform.position.y and position.y >= platform.position.y:
						landing_y = minf(landing_y, platform.position.y)
				if position.y >= landing_y:
					position.y = landing_y
					vy = 0.0
					on_ground = true
					jumps_used = 0
					coyote_timer = 0.12
					squash = 0.28
		else:
			coyote_timer = 0.12
		if was_on_ground and not on_ground:
			squash = -0.14
		squash = lerpf(squash, 0.0, minf(1.0, 12.0 * delta))
		hurt = maxf(hurt - delta, 0.0)
		double_jump_timer = maxf(0.0, double_jump_timer - delta)
		_update_animation(delta)
		queue_redraw()

	func _update_animation(delta: float) -> void:
		var next := "idle"
		if hurt > 0.0:
			next = "hit"
		elif double_jump_timer > 0.0:
			next = "double"
		elif on_ground:
			next = "run" if absf(vx) > 20.0 else "idle"
		else:
			next = "jump" if vy < 30.0 else "fall"
		if next != anim_name:
			anim_name = next
			anim_frame = 0
			anim_timer = 0.0
		anim_timer += delta
		var frame_time := 0.13 if absf(vx) < (WALK_SPEED + RUN_SPEED) * 0.5 else 0.085
		if anim_name == "idle":
			frame_time = 0.15
		elif anim_name == "hit":
			frame_time = 0.11
		elif anim_name == "double":
			frame_time = 0.09
		if anim_timer >= frame_time:
			anim_timer = 0.0
			anim_frame = (anim_frame + 1) % ANIM_FRAMES[anim_name]

	func _draw() -> void:
		var tex: Texture2D = IDLE_TEX
		match anim_name:
			"run": tex = RUN_TEX
			"jump": tex = JUMP_TEX
			"fall": tex = FALL_TEX
			"hit": tex = HIT_TEX
			"double": tex = DOUBLE_JUMP_TEX
			"wall": tex = WALL_JUMP_TEX
		var tint := Color.WHITE
		if hurt > 0.0 and int(hurt * 18.0) % 2 == 0:
			tint = Color(1.0, 0.65, 0.65)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(facing * (1.0 + squash * 0.35), 1.0 - squash))
		# Warm halo and a tiny spark trail make the original frog pop against the dark forest.
		draw_circle(Vector2(0, -24), 25.0, Color(1.0, 0.82, 0.36, 0.13))
		draw_texture_rect_region(tex, Rect2(-24.0, -48.0, 48.0, 48.0), Rect2(float(anim_frame) * 32.0, 0.0, 32.0, 32.0), tint)
		draw_circle(Vector2(4, -27), 3.0 + sin(t * 10.0) * 0.8, Color(1.0, 0.94, 0.6, 0.9))


# =====================================================================
#  TRAPS  (ground hazards, chasms, falling rocks, and moving creatures)
#  origin = ground level; ghost floats, beast + ghost walk toward the player once close
# =====================================================================
class Trap extends Node2D:
	const SPIKE_TEX := preload("res://asset1/Assets/Spike.png")
	var kind := "cactus"
	var box := Rect2()
	var vx := 0.0
	var base_pos := Vector2.ZERO
	var ground_y := 520.0
	var spawn_x := 0.0
	var hit := false
	var cleared := false
	var active := false
	var t := 0.0
	var open_amt := 0.0
	var fall_vy := 0.0
	var triggered := false
	var player_ref = null

	func setup(k: String, x: float, gy: float) -> void:
		kind = k
		spawn_x = x
		ground_y = gy
		base_pos = Vector2(x, gy)
		match k:
			"cactus":
				box = Rect2(-18, -64, 36, 64)
			"poison_plant":
				box = Rect2(-28, -44, 56, 44)
			"worms":
				box = Rect2(-42, -22, 84, 22)
			"trapdoor":
				box = Rect2(-50, -8, 100, 28)
			"insects":
				box = Rect2(-36, -52, 72, 44)
			"ghost":
				box = Rect2(-22, -24, 44, 48)
				vx = -112.0
				base_pos.y = gy - 105.0   # floats at head height: DON'T jump into it
			"beast":
				box = Rect2(-50, -36, 90, 36)
				vx = -105.0
			"chasm":
				box = Rect2(-68, -8, 136, 420)
			"spikes":
				box = Rect2(-44, -26, 88, 26)
			"rockfall":
				box = Rect2(-17, -20, 34, 38)
				base_pos.y = gy - 180.0
			"wisp":
				box = Rect2(-23, -22, 46, 44)
				base_pos.y = gy - 94.0
			"rolling_rock":
				box = Rect2(-23, -28, 46, 40)
				vx = -138.0
		position = base_pos

	func hitbox() -> Rect2:
		return Rect2(position + box.position, box.size)

	func reset_trap() -> void:
		position = base_pos
		hit = false
		cleared = false
		active = false
		open_amt = 0.0

	func step(delta: float) -> void:
		t += delta
		var distance_ahead := 100000.0
		if player_ref != null:
			distance_ahead = position.x - player_ref.position.x
		if not active:
			var trigger_distance := 300.0 if kind == "rockfall" else 420.0
			if distance_ahead < trigger_distance and distance_ahead > -100.0:
				active = true
		else:
			if kind != "rockfall":
				position.x += vx * delta
		if kind == "ghost":
			position.y = base_pos.y + sin(t * 3.0) * 10.0
		elif kind == "wisp":
			position.y = base_pos.y + sin(t * 3.8) * 30.0
			position.x = base_pos.x + sin(t * 2.0) * 36.0 if active else base_pos.x
		elif kind == "rockfall":
			if active:
				fall_vy = minf(fall_vy + 1050.0 * delta, 760.0)
				position.y = minf(position.y + fall_vy * delta, ground_y - 19.0)
				if position.y >= ground_y - 19.0:
					fall_vy = 0.0
		elif kind == "trapdoor" and player_ref != null:
			var d: float = position.x - player_ref.position.x
			var want := 0.0
			if d < 240.0 and d > -70.0:
				want = 1.0
			open_amt = move_toward(open_amt, want, delta * 3.0)
		if player_ref != null and absf(position.x - player_ref.position.x) < 1000.0:
			queue_redraw()

	func _draw() -> void:
		match kind:
			"chasm":
				draw_rect(Rect2(-78, -8, 156, 680), Color(0.008, 0.008, 0.018))
				for side in [-1.0, 1.0]:
					for i in range(5):
						draw_line(Vector2(side * 68.0, 4.0 + i * 12.0), Vector2(side * (56.0 + i * 2.0), 13.0 + i * 12.0), Color(0.22, 0.18, 0.24), 3.0)
			"spikes":
				for i in range(5):
					draw_texture_rect(SPIKE_TEX, Rect2(-44.0 + i * 18.0, -28.0, 20.0, 28.0), false, Color(0.85, 0.9, 0.97))
				draw_rect(Rect2(-46.0, -3.0, 92.0, 6.0), Color(0.42, 0.35, 0.3))
			"rockfall":
				if not active:
					var pulse := 0.55 + sin(t * 8.0) * 0.2
					draw_arc(Vector2(0, 0), 15.0, PI, TAU, 16, Color(1.0, 0.72, 0.28, pulse), 3.0)
				else:
					draw_circle(Vector2.ZERO, 24.0, Color(0.9, 0.42, 0.24, 0.18))
				draw_colored_polygon(PackedVector2Array([Vector2(-16, -8), Vector2(-11, -19), Vector2(3, -22), Vector2(18, -11), Vector2(14, 7), Vector2(-4, 14), Vector2(-18, 5)]), Color(0.52, 0.46, 0.48))
				draw_circle(Vector2(-6, -7), 3.0, Color(0.7, 0.65, 0.64))
			"wisp":
				for i in range(4, 0, -1):
					draw_circle(Vector2.ZERO, 8.0 + i * 8.0, Color(0.48, 0.88, 1.0, 0.08))
				draw_circle(Vector2.ZERO, 12.0, Color(0.61, 0.91, 1.0))
				draw_circle(Vector2(-4, -3), 3.0, Color.WHITE)
			"rolling_rock":
				draw_circle(Vector2.ZERO, 21.0, Color(0.38, 0.35, 0.4))
				draw_arc(Vector2.ZERO, 15.0, t, t + PI * 1.5, 16, Color(0.65, 0.6, 0.66), 4.0)
			"cactus":
				var g := Color(0.25, 0.6, 0.3)
				draw_rect(Rect2(-9, -64, 18, 64), g)
				draw_circle(Vector2(0, -64), 9.0, g)
				draw_rect(Rect2(-24, -34, 16, 8), g)
				draw_rect(Rect2(-24, -50, 8, 24), g)
				draw_rect(Rect2(8, -44, 16, 8), g)
				draw_rect(Rect2(16, -58, 8, 22), g)
				for i in range(5):
					var y := -58.0 + i * 11.0
					draw_line(Vector2(-9, y), Vector2(-14, y - 2), Color(0.9, 0.95, 0.8), 1.5)
					draw_line(Vector2(9, y), Vector2(14, y - 2), Color(0.9, 0.95, 0.8), 1.5)
				draw_texture_rect(SPIKE_TEX, Rect2(21, -32, 16, 32), false, Color(0.82, 0.88, 0.92, 0.8))
			"poison_plant":
				var stem := Color(0.2, 0.45, 0.25)
				draw_line(Vector2(-14, 0), Vector2(-22, -30), stem, 4.0)
				draw_line(Vector2(0, 0), Vector2(0, -42), stem, 4.0)
				draw_line(Vector2(14, 0), Vector2(23, -26), stem, 4.0)
				var pulse := 1.0 + sin(t * 4.0) * 0.15
				for p in [Vector2(-22, -30), Vector2(0, -42), Vector2(23, -26)]:
					draw_circle(p, 10.0, Color(0.6, 0.2, 0.8))
					draw_circle(p, 4.5 * pulse, Color(0.65, 1.0, 0.3))
			"worms":
				for w in range(3):
					var pts := PackedVector2Array()
					for i in range(11):
						var x := -40.0 + i * 8.0
						pts.append(Vector2(x, -7.0 - w * 4.0 + sin(t * 5.0 + x * 0.15 + w * 2.0) * 6.0))
					draw_polyline(pts, Color(0.88, 0.45, 0.52), 7.0)
					draw_circle(pts[pts.size() - 1], 4.5, Color(0.95, 0.55, 0.6))
					draw_circle(pts[pts.size() - 1] + Vector2(1, -1), 1.5, Color.BLACK)
			"insects":
				for i in range(10):
					var ang := t * (4.0 + float(i % 3)) + i * 0.9
					var p := Vector2(cos(ang) * 30.0, -32.0 + sin(ang * 1.3) * 16.0)
					draw_circle(p, 3.2, Color(0.95, 0.85, 0.35))
					draw_line(p, p + Vector2(-5, -4), Color(1, 1, 1, 0.75), 1.5)
					draw_line(p, p + Vector2(5, -4), Color(1, 1, 1, 0.75), 1.5)
			"trapdoor":
				draw_rect(Rect2(-50, 0, 100, 60), Color(0.01, 0.01, 0.02, open_amt))
				var a := open_amt * 1.35
				var wood := Color(0.48, 0.32, 0.16)
				draw_line(Vector2(-50, 0), Vector2(-50 + cos(a) * 50.0, sin(a) * 50.0), wood, 7.0)
				draw_line(Vector2(50, 0), Vector2(50 - cos(a) * 50.0, sin(a) * 50.0), wood, 7.0)
			"ghost":
				var body := Color(0.82, 0.9, 1.0)
				draw_circle(Vector2.ZERO, 42.0, Color(0.7, 0.85, 1.0, 0.12))
				draw_circle(Vector2(0, -6), 22.0, body)
				draw_rect(Rect2(-22, -6, 44, 24), body)
				for i in range(3):
					draw_circle(Vector2(-14.0 + i * 14.0, 18.0 + sin(t * 6.0 + i) * 3.0), 8.0, body)
				draw_circle(Vector2(-8, -8), 4.0, Color.BLACK)
				draw_circle(Vector2(8, -8), 4.0, Color.BLACK)
				draw_circle(Vector2(0, 5), 5.0, Color.BLACK)
			"beast":
				var fur := Color(0.4, 0.24, 0.18)
				draw_rect(Rect2(-30, -34, 56, 24), fur)
				draw_circle(Vector2(-38, -34), 13.0, fur)
				draw_rect(Rect2(-58, -34, 20, 10), fur)
				draw_colored_polygon(PackedVector2Array([Vector2(-46, -44), Vector2(-42, -62), Vector2(-34, -46)]), fur)
				for i in range(4):
					var lx := -24.0 + i * 14.0
					draw_line(Vector2(lx, -12), Vector2(lx + sin(t * 10.0 + i * PI * 0.5) * 8.0, 0), fur, 6.0)
				draw_line(Vector2(26, -28), Vector2(44, -44), fur, 6.0)
				draw_circle(Vector2(-42, -38), 5.0, Color(1.0, 0.15, 0.1, 0.35))
				draw_circle(Vector2(-42, -38), 3.0, Color(1.0, 0.2, 0.1))


# =====================================================================
#  GOAL ORB (the little ball of light at the end)
# =====================================================================
class Orb extends Node2D:
	var t := 0.0
	var collected := false

	func hitbox() -> Rect2:
		return Rect2(position.x - 30.0, position.y - 30.0, 60.0, 60.0)

	func _process(delta: float) -> void:
		t += delta
		queue_redraw()

	func _draw() -> void:
		var pulse := 1.0 + sin(t * 4.0) * 0.15
		for i in range(6, 0, -1):
			draw_circle(Vector2.ZERO, 10.0 * pulse + i * 7.0, Color(1.0, 0.9, 0.5, 0.07))
		draw_circle(Vector2.ZERO, 10.0 * pulse, Color(1.0, 0.97, 0.8))


# =====================================================================
#  BOUNCE BACK PORTAL
# =====================================================================
class Portal extends Node2D:
	var t := 0.0
	var amt := 0.0   # 0 = closed, 1 = fully open

	func _process(delta: float) -> void:
		t += delta
		queue_redraw()

	func _draw() -> void:
		if amt <= 0.01:
			return
		for i in range(8):
			var dir := 1.0
			if i % 2 == 1:
				dir = -1.0
			var a := t * (2.0 + i * 0.4) * dir
			var r := (16.0 + i * 9.0) * amt
			draw_arc(Vector2.ZERO, r, a, a + PI * 1.2, 24, Color(0.45 + 0.07 * i, 0.6, 1.0, 0.9), 3.0)
		draw_circle(Vector2.ZERO, 14.0 * amt, Color(0.85, 0.92, 1.0, 0.9))
		draw_circle(Vector2.ZERO, 34.0 * amt, Color(0.5, 0.6, 1.0, 0.2))


# =====================================================================
#  BACKGROUND  (far = hills + pines with parallax, near = ground, dead trees, lamps)
#  When the game is won, set_lit(0..1) turns the dead world green and alive.
# =====================================================================
class Background extends Node2D:
	const SKY_TEX := preload("res://bg_3/bg_Layer1_sky.png")
	const MOUNTAIN_TEX := preload("res://bg_3/bg_Layer2_mountains.png")
	const FOREST_TEX := preload("res://bg_3/bg_Layer3_forest.png")
	const FOREST_MID_TEX := preload("res://bg_3/bg_Layer4_forest.png")
	const FOREST_NEAR_TEX := preload("res://bg_3/bg_Layer5_forest.png")
	const TREE_A_TEX := preload("res://asset1/Assets/Trees/TreeA-Spritesheet.png")
	const TREE_B_TEX := preload("res://asset1/Assets/Trees/TreeB-Spritesheet.png")
	const ROCK_A_TEX := preload("res://asset1/Assets/Rocks/RockA.png")
	const ROCK_B_TEX := preload("res://asset1/Assets/Rocks/RockB.png")
	const ROCK_C_TEX := preload("res://asset1/Assets/Rocks/RockC.png")
	var kind := "near"
	var lit := 0.0
	var ground_y := 520.0
	var lamps: Array = []
	var trees: Array = []
	var tufts: Array = []
	var x_min := -1000.0
	var x_max := 16000.0

	func setup(k: String, level_len: float, gy: float, lamp_list: Array) -> void:
		kind = k
		ground_y = gy
		lamps = lamp_list
		var rng := RandomNumberGenerator.new()
		if kind == "near":
			rng.seed = 4242
			x_max = level_len + 1800.0
		else:
			rng.seed = 99
			x_max = level_len * 0.6 + 1400.0
		var x := x_min
		while x < x_max:
			trees.append([x, rng.randf_range(90.0, 230.0), rng.randf_range(-0.35, 0.35)])
			x += rng.randf_range(150.0, 420.0)
		x = x_min
		while x < x_max:
			tufts.append(x)
			x += rng.randf_range(40.0, 130.0)
		queue_redraw()

	func set_lit(v: float) -> void:
		lit = v
		queue_redraw()

	func tint(dim: Color, bright: Color) -> Color:
		return dim.lerp(bright, lit)

	func hill_y(x: float) -> float:
		return ground_y - 110.0 - (sin(x * 0.0045) * 50.0 + sin(x * 0.013) * 22.0)

	func _draw() -> void:
		if kind == "far":
			_draw_far()
		else:
			_draw_near()

	func _draw_far() -> void:
		# The supplied five-layer Haven forest pack is drawn in parallax bands.
		var blocks := int(ceil((x_max - x_min) / 1152.0)) + 1
		for i in range(blocks):
			var bx := x_min + float(i) * 1152.0
			var dst := Rect2(bx, 0.0, 1152.0, 648.0)
			draw_texture_rect(SKY_TEX, dst, false, Color(0.72, 0.78, 0.94, 0.9))
			draw_texture_rect(MOUNTAIN_TEX, dst, false, Color(0.72, 0.82, 0.95, 0.82))
			draw_texture_rect(FOREST_TEX, dst, false, Color(0.72, 0.86, 0.8, 0.74))
			draw_texture_rect(FOREST_MID_TEX, dst, false, Color(0.78, 0.82, 0.75, 0.68))
			draw_texture_rect(FOREST_NEAR_TEX, dst, false, Color(0.72, 0.74, 0.72, 0.64))
		var pts := PackedVector2Array()
		var x := x_min
		while x <= x_max:
			pts.append(Vector2(x, hill_y(x)))
			x += 50.0
		pts.append(Vector2(x_max, ground_y + 400.0))
		pts.append(Vector2(x_min, ground_y + 400.0))
		draw_colored_polygon(pts, tint(Color(0.05, 0.05, 0.09), Color(0.5, 0.72, 0.85)))
		var pine := tint(Color(0.07, 0.06, 0.11), Color(0.22, 0.5, 0.38))
		for tr in trees:
			var bx: float = tr[0]
			var h: float = float(tr[1]) * 0.45
			var by := hill_y(bx) + 6.0
			draw_colored_polygon(PackedVector2Array([Vector2(bx - 20.0, by), Vector2(bx, by - h), Vector2(bx + 20.0, by)]), pine)

	func _draw_near() -> void:
		var w := x_max - x_min
		draw_rect(Rect2(x_min, ground_y, w, 700.0), tint(Color(0.07, 0.06, 0.09), Color(0.33, 0.58, 0.28)))
		draw_rect(Rect2(x_min, ground_y, w, 7.0), tint(Color(0.16, 0.14, 0.19), Color(0.47, 0.78, 0.35)))
		var dead := tint(Color(0.12, 0.09, 0.12), Color(0.42, 0.28, 0.18))
		# AtlasTexture regions expose the two supplied tree poses without importing a new sprite sheet.
		var tree_a := AtlasTexture.new()
		tree_a.atlas = TREE_A_TEX
		tree_a.region = Rect2(0, 0, 64, 64)
		var tree_b := AtlasTexture.new()
		tree_b.atlas = TREE_B_TEX
		tree_b.region = Rect2(64, 0, 64, 64)
		for i in range(0, trees.size(), 2):
			var tr = trees[i]
			var tx: float = tr[0]
			var tex := tree_a if i % 4 == 0 else tree_b
			draw_texture_rect(tex, Rect2(tx - 48.0, ground_y - 152.0, 96.0, 152.0), false, Color(0.42, 0.47, 0.46, 0.46))
		for tr in trees:
			var bx: float = tr[0]
			var h: float = tr[1]
			var lean: float = tr[2]
			var base := Vector2(bx, ground_y)
			var tip := base + Vector2(lean * h, -h)
			var b1 := base.lerp(tip, 0.55)
			var b2 := base.lerp(tip, 0.8)
			var e1 := b1 + Vector2(-45.0, -38.0)
			var e2 := b2 + Vector2(40.0, -34.0)
			draw_line(base, tip, dead, 9.0)
			draw_line(b1, e1, dead, 5.0)
			draw_line(b2, e2, dead, 4.0)
			if lit > 0.02:
				var leaf := Color(0.25, 0.65, 0.28, lit)
				draw_circle(tip + Vector2(0, -10), 38.0, leaf)
				draw_circle(e1, 24.0, leaf)
				draw_circle(e2, 22.0, leaf)
		var gcol := tint(Color(0.12, 0.1, 0.15), Color(0.3, 0.7, 0.3))
		for tx in tufts:
			draw_line(Vector2(tx, ground_y), Vector2(tx - 4.0, ground_y - 9.0), gcol, 2.0)
			draw_line(Vector2(tx, ground_y), Vector2(tx + 5.0, ground_y - 11.0), gcol, 2.0)
		if lit > 0.3:
			for i in range(0, tufts.size(), 3):
				var fc := Color(1.0, 0.55 + 0.4 * sin(i * 1.7), 0.6, lit)
				draw_circle(Vector2(tufts[i], ground_y - 14.0), 3.0, fc)
		for i in range(0, tufts.size(), 9):
			var rock_tex: Texture2D = [ROCK_A_TEX, ROCK_B_TEX, ROCK_C_TEX][i % 3]
			draw_texture_rect(rock_tex, Rect2(tufts[i] - 14.0, ground_y - 19.0, 28.0, 19.0), false, Color(0.64, 0.62, 0.72, 0.72))
		for lx in lamps:
			var lp := Vector2(lx, ground_y)
			draw_line(lp, lp + Vector2(0, -74), Color(0.25, 0.2, 0.2), 5.0)
			draw_circle(lp + Vector2(0, -80), 11.0, Color(1.0, 0.86, 0.45))
			draw_circle(lp + Vector2(0, -80), 22.0, Color(1.0, 0.86, 0.45, 0.18))


# =====================================================================
#  MAIN GAME
# =====================================================================
enum State { READY, RUN, BOUNCING, WON, PAUSED, GAME_OVER }

var state: State = State.READY
var radius := START_R
var target_radius := START_R
var streak := 0
var bounces := 0
var checkpoint_x := 120.0
var checkpoints: Array = []
var traps: Array = []
var parkour_sections: Array = []
var parkour_platforms: Array[Rect2] = []
var pit_rects: Array[Rect2] = []
var time := 0.0
var jump_buffer := 0.0
var invuln := 0.0
var shake := 0.0
var cam_x := 0.0
var bounce_t := 0.0
var bounce_teleported := false
var win_t := 0.0
var msg_timer := 0.0

var world: Node2D
var bg_far
var bg_near
var player
var orb
var portal
var dark_rect: ColorRect
var dark_mat: ShaderMaterial
var hud_label: Label
var msg_label: Label
var progress_bg: ColorRect
var progress_fill: ColorRect
var light_bg: ColorRect
var light_fill: ColorRect
var light_label: Label
var paused_state: State = State.RUN
var best_distance := 0.0
var menu_layer: CanvasLayer
var menu_root: Control
var menu_shade: ColorRect
var start_panel: PanelContainer
var pause_panel: PanelContainer
var game_over_panel: PanelContainer
var victory_panel: PanelContainer
var danger_label: Label
var ambience_player: AudioStreamPlayer
var run_enabled := false
var last_run_tap_time := -1.0


func _ready() -> void:
	# Keep the supplied 32px pixel art crisp at every camera zoom level.
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	RenderingServer.set_default_clear_color(Color(0.012, 0.012, 0.03))
	var ambience := AMBIENCE_STREAM as AudioStreamMP3
	ambience.loop = true
	ambience_player = AudioStreamPlayer.new()
	ambience_player.stream = ambience
	ambience_player.volume_db = -12.0
	add_child(ambience_player)
	ambience_player.play()
	_ensure_input_actions()
	world = Node2D.new()
	add_child(world)

	checkpoints = [120.0]
	var cp := CHECKPOINT_GAP
	while cp < LEVEL_LEN - 1200.0:
		checkpoints.append(cp)
		cp += CHECKPOINT_GAP

	bg_far = Background.new()
	bg_far.setup("far", LEVEL_LEN, GROUND_Y, checkpoints)
	world.add_child(bg_far)
	bg_near = Background.new()
	bg_near.setup("near", LEVEL_LEN, GROUND_Y, checkpoints)
	world.add_child(bg_near)
	_build_parkour()

	player = Player.new()
	player.ground_y = GROUND_Y
	player.position = Vector2(120.0, GROUND_Y)

	_build_traps()

	orb = Orb.new()
	orb.position = Vector2(LEVEL_LEN, GROUND_Y - 70.0)
	world.add_child(orb)
	world.add_child(player)
	portal = Portal.new()
	world.add_child(portal)

	_build_overlay()
	_build_hud()
	_show_menu(start_panel)
	cam_x = player.position.x + get_viewport_rect().size.x * 0.22


func _exit_tree() -> void:
	if ambience_player != null:
		ambience_player.stop()
		ambience_player.stream = null


func _ensure_input_actions() -> void:
	for action in ["move_left", "move_right"]:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
	var key_map := {"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT]}
	for action in key_map:
		for keycode in key_map[action]:
			var key_event := InputEventKey.new()
			key_event.physical_keycode = keycode
			if not InputMap.action_has_event(action, key_event):
				InputMap.action_add_event(action, key_event)


func _build_parkour() -> void:
	var starts := [2200.0, 6800.0, 13400.0, 18300.0, 25700.0, 33000.0, 40800.0, 45400.0]
	for i in range(starts.size()):
		var course := PARKOUR_SCENE.instantiate()
		course.setup(starts[i], GROUND_Y, i)
		world.add_child(course)
		parkour_sections.append(course)
		parkour_platforms.append_array(course.get_platform_rects())
		pit_rects.append(course.get_gap_rect())


func _build_traps() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var gentle := ["spikes", "cactus", "poison_plant", "worms", "insects", "rolling_rock"]
	var middle := ["spikes", "cactus", "poison_plant", "trapdoor", "insects", "ghost", "rockfall", "wisp", "rolling_rock", "beast"]
	var late := ["spikes", "trapdoor", "ghost", "beast", "rockfall", "wisp", "rolling_rock", "chasm", "chasm"]
	var last := ""
	var gap_placed := false
	var x := 760.0
	while x < LEVEL_LEN - 560.0:
		var near_cp := false
		for c in checkpoints:
			if absf(x - c) < 300.0:
				near_cp = true
		for course in parkour_sections:
			var gap: Rect2 = course.get_gap_rect()
			if x > gap.position.x - 420.0 and x < gap.end.x + 420.0:
				near_cp = true
		if not near_cp:
			var progress := x / LEVEL_LEN
			var kinds: Array = gentle if progress < 0.28 else (middle if progress < 0.68 else late)
			var k: String = kinds[rng.randi_range(0, kinds.size() - 1)]
			if progress >= 0.72 and not gap_placed:
				k = "chasm"
			if k == "chasm" and last == "chasm":
				k = "spikes"
			if k == "chasm":
				gap_placed = true
			last = k
			var tr := Trap.new()
			tr.player_ref = player
			tr.setup(k, x, GROUND_Y)
			world.add_child(tr)
			traps.append(tr)
			if k == "chasm":
				pit_rects.append(Rect2(x - 78.0, GROUND_Y, 156.0, 640.0))
			elif progress > 0.22 and progress < 0.92 and k in ["spikes", "cactus", "trapdoor", "worms", "rockfall", "rolling_rock"] and rng.randf() < (0.24 if progress < 0.7 else 0.34):
				var combo_x := x + rng.randf_range(155.0, 195.0)
				var combo_is_clear := true
				for c in checkpoints:
					if absf(combo_x - c) < 180.0:
						combo_is_clear = false
				for course in parkour_sections:
					var course_gap: Rect2 = course.get_gap_rect()
					if combo_x > course_gap.position.x - 100.0 and combo_x < course_gap.end.x + 100.0:
						combo_is_clear = false
				if combo_is_clear:
					var combo := Trap.new()
					combo.player_ref = player
					combo.setup("wisp", combo_x, GROUND_Y)
					world.add_child(combo)
					traps.append(combo)
		x += rng.randf_range(330.0, 440.0)


func _make_label(font_size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color(1.0, 0.93, 0.7))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l


func _build_overlay() -> void:
	var dark_layer := CanvasLayer.new()
	dark_layer.layer = 5
	add_child(dark_layer)
	dark_rect = ColorRect.new()
	dark_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dark_layer.add_child(dark_rect)
	var sh := Shader.new()
	sh.code = DARK_SHADER
	dark_mat = ShaderMaterial.new()
	dark_mat.shader = sh
	dark_rect.material = dark_mat
	dark_rect.size = get_viewport_rect().size


func _build_hud() -> void:
	var hud := CanvasLayer.new()
	hud.layer = 10
	add_child(hud)

	progress_bg = ColorRect.new()
	progress_bg.color = Color(1, 1, 1, 0.12)
	progress_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(progress_bg)
	progress_fill = ColorRect.new()
	progress_fill.color = Color(1.0, 0.85, 0.4)
	progress_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(progress_fill)
	light_bg = ColorRect.new()
	light_bg.color = Color(0.02, 0.02, 0.04, 0.78)
	light_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(light_bg)
	light_fill = ColorRect.new()
	light_fill.color = Color(1.0, 0.82, 0.38)
	light_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(light_fill)

	hud_label = _make_label(22)
	hud_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hud_label.position = Vector2(18, 16)
	hud_label.size = Vector2(560.0, 30.0)
	hud.add_child(hud_label)
	danger_label = _make_label(17)
	danger_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	danger_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	danger_label.position = Vector2(18.0, 45.0)
	danger_label.size = Vector2(550.0, 26.0)
	danger_label.modulate = Color(1.0, 0.62, 0.43)
	hud.add_child(danger_label)
	light_label = _make_label(13)
	light_label.text = "SPARK LIGHT"
	light_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	light_label.position = Vector2(0.0, 0.0)
	light_label.size = Vector2(220.0, 18.0)
	light_label.add_theme_font_size_override("font_size", 13)
	hud.add_child(light_label)

	msg_label = _make_label(64)
	hud.add_child(msg_label)
	msg_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	msg_label.offset_top = -170.0
	msg_label.offset_bottom = -170.0

	_build_menus()


func _make_menu_panel() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.anchor_left = 0.5
	panel.anchor_right = 0.5
	panel.anchor_top = 0.5
	panel.anchor_bottom = 0.5
	panel.offset_left = -340.0
	panel.offset_right = 340.0
	panel.offset_top = -230.0
	panel.offset_bottom = 230.0
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.018, 0.04, 0.055, 0.97)
	style.border_color = Color(0.89, 0.72, 0.39, 0.92)
	style.set_border_width_all(2)
	style.set_corner_radius_all(18)
	style.set_content_margin_all(34.0)
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.55)
	style.shadow_size = 18
	panel.add_theme_stylebox_override("panel", style)
	panel.visible = false
	return panel


func _make_menu_button(caption: String) -> Button:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(280.0, 54.0)
	button.focus_mode = Control.FOCUS_ALL
	button.add_theme_font_size_override("font_size", 20)
	button.add_theme_color_override("font_color", Color(0.09, 0.08, 0.04))
	button.add_theme_color_override("font_hover_color", Color(0.04, 0.07, 0.05))
	button.add_theme_color_override("font_pressed_color", Color(0.05, 0.05, 0.04))
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.95, 0.78, 0.42)
	normal.set_corner_radius_all(12)
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(1.0, 0.88, 0.59)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.81, 0.64, 0.32)
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", hover)
	return button


func _menu_contents(panel: PanelContainer, heading: String, body: String) -> VBoxContainer:
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 15)
	panel.add_child(stack)
	var title := _make_label(40)
	title.text = heading
	stack.add_child(title)
	var description := _make_label(18)
	description.text = body
	description.add_theme_color_override("font_color", Color(0.82, 0.88, 0.83))
	description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	description.custom_minimum_size = Vector2(560.0, 104.0)
	stack.add_child(description)
	return stack


func _build_menus() -> void:
	menu_layer = CanvasLayer.new()
	menu_layer.layer = 20
	add_child(menu_layer)
	menu_root = Control.new()
	menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(menu_root)
	menu_shade = ColorRect.new()
	menu_shade.color = Color(0.005, 0.014, 0.023, 0.76)
	menu_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_shade.mouse_filter = Control.MOUSE_FILTER_STOP
	menu_root.add_child(menu_shade)

	start_panel = _make_menu_panel()
	menu_root.add_child(start_panel)
	var start_stack := _menu_contents(start_panel, "THE LAST SPARK", "A little frog. One fading light. A forest waiting to wake.\n\nWALK   A / D or LEFT / RIGHT\nRUN   DOUBLE-TAP D TO TOGGLE RUNNING\nJUMP   SPACE / W / UP - PRESS AGAIN IN AIR TO DOUBLE JUMP\nPAUSE   ESC - RESTART   R\n\nYour spark only fades when you are hit. Clear hazards and reach lamps to restore it. A 2-3 minute forest journey with eight parkour trials awaits.")
	var start_button := _make_menu_button("START GAME")
	start_button.pressed.connect(_start_game)
	start_stack.add_child(start_button)

	pause_panel = _make_menu_panel()
	menu_root.add_child(pause_panel)
	var pause_stack := _menu_contents(pause_panel, "PAUSED", "The spark is safe for a moment.")
	var resume_button := _make_menu_button("RESUME")
	resume_button.pressed.connect(_resume_game)
	pause_stack.add_child(resume_button)
	var pause_restart := _make_menu_button("RESTART")
	pause_restart.pressed.connect(_restart_game)
	pause_stack.add_child(pause_restart)

	game_over_panel = _make_menu_panel()
	menu_root.add_child(game_over_panel)
	var over_stack := _menu_contents(game_over_panel, "THE SPARK WENT OUT", "The valley is still waiting. Your nearest lamp will remember the way.")
	var over_restart := _make_menu_button("RESTART")
	over_restart.pressed.connect(_restart_game)
	over_stack.add_child(over_restart)

	victory_panel = _make_menu_panel()
	menu_root.add_child(victory_panel)
	var victory_stack := _menu_contents(victory_panel, "YOU WON!", "The last spark restored the forest.\n\nThe valley is alive again.")
	var victory_restart := _make_menu_button("PLAY AGAIN")
	victory_restart.pressed.connect(_restart_game)
	victory_stack.add_child(victory_restart)
	menu_root.visible = false


func _show_menu(panel: PanelContainer) -> void:
	for item in [start_panel, pause_panel, game_over_panel, victory_panel]:
		if item != null:
			item.visible = item == panel
	menu_root.visible = panel != null
	if panel != null:
		var first_button: Button = null
		for child in panel.get_children():
			if child is VBoxContainer:
				for button in child.get_children():
					if button is Button:
						first_button = button
						break
				if first_button != null:
					break
		if first_button != null:
			first_button.grab_focus()


func _start_game() -> void:
	if state == State.READY:
		state = State.RUN
	_show_menu(null)


func _resume_game() -> void:
	if state == State.PAUSED:
		state = paused_state
	_show_menu(null)


func _restart_game() -> void:
	get_tree().reload_current_scene()


func _say(text: String, dur: float) -> void:
	msg_label.text = text
	msg_timer = dur
	msg_label.modulate.a = 1.0


# ---------------------------------------------------------------------
#  INPUT
# ---------------------------------------------------------------------
func _unhandled_input(event: InputEvent) -> void:
	var pressed := false
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if state == State.PAUSED:
				_resume_game()
			elif state == State.RUN or state == State.BOUNCING:
				paused_state = state
				state = State.PAUSED
				player.vx = 0.0
				_show_menu(pause_panel)
			return
		if event.keycode == KEY_R:
			_restart_game()
			return
		if event.keycode == KEY_D or event.physical_keycode == KEY_D:
			if state == State.READY:
				_start_game()
				last_run_tap_time = time
			elif state == State.RUN:
				if last_run_tap_time >= 0.0 and time - last_run_tap_time <= RUN_DOUBLE_TAP_WINDOW:
					run_enabled = not run_enabled
					last_run_tap_time = -1.0
					_say("RUNNING" if run_enabled else "WALKING", 0.8)
				else:
					last_run_tap_time = time
			return
		if event.keycode in [KEY_SPACE, KEY_UP, KEY_W]:
			pressed = true
		elif event.keycode in [KEY_A, KEY_LEFT, KEY_RIGHT]:
			if state == State.READY:
				_start_game()
	if not pressed:
		return
	if state == State.READY:
		_start_game()
	if state == State.GAME_OVER:
		_restart_game()
		return
	if state == State.PAUSED:
		_resume_game()
		return
	jump_buffer = 0.14


# ---------------------------------------------------------------------
#  MAIN LOOP
# ---------------------------------------------------------------------
func _process(delta: float) -> void:
	time += delta
	jump_buffer = maxf(jump_buffer - delta, 0.0)
	invuln = maxf(invuln - delta, 0.0)
	shake = maxf(shake - delta * 1.5, 0.0)

	match state:
		State.READY:
			player.step(delta, 0.0, parkour_platforms)
		State.RUN:
			_update_run(delta)
		State.BOUNCING:
			_update_bounce(delta)
		State.WON:
			_update_won(delta)
		State.PAUSED, State.GAME_OVER:
			pass

	_update_view(delta)
	_update_light(delta)
	_update_hud(delta)


func _update_run(delta: float) -> void:
	var direction := Input.get_axis("move_left", "move_right")
	var sprinting := direction != 0.0 and run_enabled
	if jump_buffer > 0.0 and player.can_jump():
		player.jump()
		jump_buffer = 0.0
	var over_pit := false
	var body_x: Rect2 = player.hitbox()
	for pit in pit_rects:
		if body_x.end.x > pit.position.x and body_x.position.x < pit.end.x:
			over_pit = true
			break
	if over_pit and player.on_ground and player.position.y >= GROUND_Y - 0.5:
		player.on_ground = false
		player.vy = 0.0
	player.ground_y = GROUND_Y + 500.0 if over_pit else GROUND_Y
	player.step(delta, direction, parkour_platforms, sprinting)
	player.position.x = clampf(player.position.x, 120.0, LEVEL_LEN + 120.0)
	if player.position.x <= 120.0 or player.position.x >= LEVEL_LEN + 120.0:
		player.vx = 0.0
	best_distance = maxf(best_distance, player.position.x)
	for tr in traps:
		tr.step(delta)

	# checkpoint lamps
	for cp in checkpoints:
		if cp > checkpoint_x and player.position.x >= cp:
			checkpoint_x = cp
			target_radius = maxf(target_radius, 470.0)
			_say("LAMP CHECKPOINT - SPARK RESTORED", 1.2)

	# traps: touching one shrinks the dome, passing one without touching it grows the dome
	var pb: Rect2 = player.hitbox().grow(-3.0)
	for tr in traps:
		if tr.kind == "chasm":
			continue
		if tr.hit or tr.cleared:
			continue
		var tb: Rect2 = tr.hitbox()
		if pb.intersects(tb):
			tr.hit = true
			if invuln <= 0.0:
				_on_hit()
				return
		elif player.position.x > tb.end.x + 14.0:
			tr.cleared = true
			_on_clear()

	if player.position.y > GROUND_Y + 100.0:
		_game_over()
		return
	if player.hitbox().intersects(orb.hitbox()):
		_win()


func _game_over() -> void:
	state = State.GAME_OVER
	player.vy = 0.0
	player.vx = 0.0
	_show_menu(game_over_panel)


func _on_hit() -> void:
	streak = 0
	player.hurt = 0.7
	invuln = 0.9
	shake = 0.6
	target_radius = maxf(MIN_R, target_radius - HIT_SHRINK)
	_say("SPARK DIMMED - avoid hits; clear hazards and reach lamps to restore it", 1.5)
	if target_radius <= MIN_R + 0.5:
		_start_bounce()


func _on_clear() -> void:
	streak += 1
	var grow := CLEAR_GROW + STREAK_GROW * float(mini(streak, 8))
	target_radius = minf(MAX_R, target_radius + grow)
	if streak >= 3:
		_say("STREAK x%d" % streak, 0.7)


# ---------------------------------------------------------------------
#  BOUNCE BACK: portal opens, sucks the player in, spits him out at the last checkpoint
# ---------------------------------------------------------------------
func _start_bounce() -> void:
	state = State.BOUNCING
	bounce_t = 0.0
	bounce_teleported = false
	bounces += 1
	player.position.y = GROUND_Y
	player.vy = 0.0
	player.ground_y = GROUND_Y
	player.on_ground = true
	portal.position = player.position + Vector2(0, -30)
	_say("BOUNCE BACK!", 1.8)


func _update_bounce(delta: float) -> void:
	bounce_t += delta
	var b := bounce_t
	player.step(delta, 0.0, parkour_platforms)
	if b < 0.5:
		portal.amt = b / 0.5
	elif b < 1.1:
		portal.amt = 1.0
		var k := (b - 0.5) / 0.6
		player.scale = Vector2.ONE * (1.0 - k)
		player.rotation = k * TAU * 2.0
		player.position.y = GROUND_Y - 30.0 * k
	else:
		if not bounce_teleported:
			bounce_teleported = true
			player.position = Vector2(checkpoint_x, GROUND_Y)
			player.ground_y = GROUND_Y
			player.rotation = 0.0
			player.scale = Vector2.ZERO
			player.vx = 0.0
			portal.position = player.position + Vector2(0, -30)
			radius = MIN_R                    # keep the spark visible through its recovery
			target_radius = BOUNCE_R
			streak = 0
			cam_x = player.position.x + get_viewport_rect().size.x * 0.22
			for tr in traps:
				if tr.spawn_x > checkpoint_x:
					tr.reset_trap()
		var k2 := clampf((b - 1.1) / 0.7, 0.0, 1.0)
		player.scale = Vector2.ONE * (k2 + sin(k2 * PI) * 0.3)
		portal.amt = 1.0 - k2
		if b >= 1.8:
			portal.amt = 0.0
			player.scale = Vector2.ONE
			invuln = 1.0
			state = State.RUN


# ---------------------------------------------------------------------
#  WIN: orb flies into his hands, the whole world lights up
# ---------------------------------------------------------------------
func _win() -> void:
	state = State.WON
	win_t = 0.0
	orb.collected = true
	_say("", 0.0)


func _update_won(delta: float) -> void:
	win_t += delta
	player.step(delta, 0.0, parkour_platforms)
	var chest: Vector2 = player.position + Vector2(6, -34)
	if win_t < 0.9:
		orb.position = orb.position.lerp(chest, 1.0 - exp(-6.0 * delta))
	else:
		target_radius = VICTORY_SPREAD_R
	var l := clampf((win_t - 0.9) / 2.8, 0.0, 1.0)
	bg_near.set_lit(l)
	bg_far.set_lit(l)
	RenderingServer.set_default_clear_color(Color(0.012, 0.012, 0.03).lerp(Color(0.53, 0.81, 0.96), l))
	if win_t > 2.2 and not victory_panel.visible:
		_show_menu(victory_panel)


# ---------------------------------------------------------------------
#  CAMERA / LIGHT / HUD
# ---------------------------------------------------------------------
func _update_view(delta: float) -> void:
	var view := get_viewport_rect().size
	var target_x: float = player.position.x + view.x * 0.22
	cam_x = lerpf(cam_x, target_x, 1.0 - exp(-10.0 * delta))
	var cam_y := GROUND_Y - view.y * 0.22
	var off := Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake * 24.0
	world.position = view * 0.5 - Vector2(cam_x, cam_y) + off
	bg_far.position.x = cam_x * 0.4     # parallax: far hills scroll slower


func _update_light(delta: float) -> void:
	var rate := 6.0
	if state == State.WON:
		rate = 1.6
	radius = lerpf(radius, target_radius, 1.0 - exp(-rate * delta))
	var flick := 1.0 + sin(time * 11.0) * 0.012 + sin(time * 23.0) * 0.008
	var view := get_viewport_rect().size
	dark_rect.size = view
	dark_mat.set_shader_parameter("rect_size", view)
	dark_mat.set_shader_parameter("c1", world.position + player.position + Vector2(0, -30))
	dark_mat.set_shader_parameter("r1", radius * flick)

	# the goal orb is a faint beacon so the player knows where to run
	dark_mat.set_shader_parameter("c2", world.position + orb.position)
	if orb.collected:
		dark_mat.set_shader_parameter("r2", 0.0)
	else:
		dark_mat.set_shader_parameter("r2", 80.0)

	# nearest checkpoint lamp glows a little
	var best := 120.0
	var best_d := 1000000.0
	for cp in checkpoints:
		var d := absf(cp - player.position.x)
		if d < best_d:
			best_d = d
			best = cp
	dark_mat.set_shader_parameter("c3", world.position + Vector2(best, GROUND_Y - 80.0))
	dark_mat.set_shader_parameter("r3", 90.0)


func _update_hud(delta: float) -> void:
	var view := get_viewport_rect().size
	hud_label.size.x = view.x - 280.0
	danger_label.size.x = view.x - 300.0
	progress_bg.size = Vector2(view.x, 6.0)
	progress_fill.size = Vector2(view.x * clampf(player.position.x / LEVEL_LEN, 0.0, 1.0), 6.0)
	light_bg.position = Vector2(view.x - 244.0, 20.0)
	light_label.position = Vector2(view.x - 244.0, 0.0)
	light_bg.size = Vector2(220.0, 14.0)
	light_fill.position = light_bg.position + Vector2(2.0, 2.0)
	light_fill.size = Vector2(216.0 * clampf(radius / MAX_R, 0.0, 1.0), 10.0)
	var light_ratio := clampf(radius / MAX_R, 0.0, 1.0)
	var warning_color := Color(1.0, 0.32, 0.25)
	var healthy_color := Color(1.0, 0.82, 0.4)
	light_fill.color = warning_color.lerp(healthy_color, smoothstep(0.16, 0.48, light_ratio))
	var movement_mode := "RUN" if run_enabled else "WALK"
	hud_label.text = "BOUNCES %d     STREAK %d     %d%%     %s" % [bounces, streak, int(clampf(player.position.x / LEVEL_LEN * 100.0, 0.0, 100.0)), movement_mode]
	if radius < 340.0 and state == State.RUN:
		danger_label.text = "SPARK WEAK - clear hazards or reach a lamp to restore it"
		danger_label.modulate = Color(1.0, 0.48 + sin(time * 5.0) * 0.12, 0.28)
	else:
		danger_label.text = "WALK A/D   DOUBLE-TAP D: RUN   JUMP SPACE/W/UP (PRESS AGAIN IN AIR)"
		danger_label.modulate = Color(0.85, 0.9, 0.78, 0.86)
	if msg_timer > 0.0:
		msg_timer -= delta
		msg_label.modulate.a = clampf(msg_timer / 0.35, 0.0, 1.0)
		if msg_timer <= 0.0:
			msg_label.text = ""

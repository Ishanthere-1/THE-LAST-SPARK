extends Node2D
## Reusable raised platform run designed around jumping and mid-air double jumps.

const COURSE_WIDTH := 900.0
const PLATFORM_WIDTH := 250.0
const PLATFORM_HEIGHT := 18.0

var gap := Rect2()
var platforms: Array[Rect2] = []
var start_x := 0.0
var ground_y := 520.0
var layout_id := 0

const LAYOUTS := [
	[Vector2(0, -92), Vector2(215, -172), Vector2(430, -252), Vector2(645, -164)],
	[Vector2(0, -110), Vector2(215, -280), Vector2(430, -360), Vector2(645, -190)],
	[Vector2(0, -90), Vector2(215, -190), Vector2(430, -285), Vector2(645, -175)],
]


func setup(x: float, floor_y: float, layout_id: int) -> void:
	start_x = x
	ground_y = floor_y
	self.layout_id = layout_id % LAYOUTS.size()
	gap = Rect2(start_x, ground_y, COURSE_WIDTH, 640.0)
	platforms.clear()
	var layout: Array = LAYOUTS[self.layout_id]
	for i in range(layout.size()):
		var item: Vector2 = layout[i]
		var ledge_x := start_x + item.x
		var ledge_width := PLATFORM_WIDTH
		if i == 0:
			# Broad entry ledge catches players who arrive from a hazard jump.
			ledge_x -= 140.0
			ledge_width += 140.0
		platforms.append(Rect2(ledge_x, ground_y + item.y, ledge_width, PLATFORM_HEIGHT))
	queue_redraw()


func get_platform_rects() -> Array[Rect2]:
	return platforms


func get_gap_rect() -> Rect2:
	return gap


func _draw() -> void:
	# Deep, cool gaps read clearly against the regular path.
	draw_rect(gap, Color(0.007, 0.009, 0.02, 0.98))
	draw_line(Vector2(gap.position.x, ground_y), Vector2(gap.end.x, ground_y), Color(0.32, 0.26, 0.29), 5.0)
	var font := ThemeDB.fallback_font
	if font != null:
		draw_string(font, Vector2(start_x - 250.0, ground_y - 108.0), "PARKOUR  -  DOUBLE JUMP", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 16, Color(0.93, 0.81, 0.47, 0.92))
		var hint := "Double jump to the high ledge" if layout_id == 1 else "Land on the glowing ledges"
		draw_string(font, Vector2(start_x - 250.0, ground_y - 84.0), hint, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 13, Color(0.77, 0.86, 0.71, 0.82))
	for side in [-1.0, 1.0]:
		var edge_x := gap.position.x if side < 0.0 else gap.end.x
		for i in range(6):
			var y := ground_y + 12.0 + i * 15.0
			draw_line(Vector2(edge_x, y), Vector2(edge_x + side * (12.0 + i % 3 * 5.0), y + 10.0), Color(0.25, 0.2, 0.24, 0.85), 3.0)
	for i in range(platforms.size()):
		var ledge := platforms[i]
		var glow := 0.45 + sin(Time.get_ticks_msec() * 0.003 + i) * 0.12
		draw_rect(Rect2(ledge.position + Vector2(0, 5), ledge.size), Color(0.07, 0.12, 0.13, 0.95))
		draw_rect(ledge, Color(0.22, 0.31, 0.23, 0.98))
		draw_rect(Rect2(ledge.position.x, ledge.position.y, ledge.size.x, 5.0), Color(0.57, 0.68, 0.35, 1.0))
		for leaf in range(8):
			var lx := ledge.position.x + 10.0 + leaf * 22.0
			draw_line(Vector2(lx, ledge.position.y + 1.0), Vector2(lx + sin(float(leaf) * 2.0) * 4.0, ledge.position.y - 5.0), Color(0.69, 0.8, 0.42, 0.9), 2.0)
		draw_circle(Vector2(ledge.position.x + ledge.size.x * 0.5, ledge.position.y - 1.0), 11.0, Color(0.6, 0.9, 0.65, glow * 0.12))
	# Small rune stones point the eye toward the next ledge.
	for i in range(platforms.size() - 1):
		var from := Vector2(platforms[i].end.x, platforms[i].position.y - 12.0)
		var to := platforms[i + 1].position + Vector2(-10.0, -12.0)
		var mid := from.lerp(to, 0.5)
		draw_circle(mid, 4.0, Color(0.78, 0.84, 0.48, 0.65))
		draw_circle(mid, 9.0, Color(0.56, 0.78, 0.47, 0.12))
